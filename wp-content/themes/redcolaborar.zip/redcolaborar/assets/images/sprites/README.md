# Using image sprites with wd_s

- Drop an an image into images/sprites
- Run 'gulp sprites'

Images will automatically be turned into one sprite. Plus, a Sass file will automatically be generated containing the sprite details.

https://github.com/twolfson/gulp.spritesmith