# Using javascript with wd_s

- Create a new javascript file and place it in /concat
- Each file should act as a partial and contain one statement
- Running 'gulp scripts' will optimize and concatenate script into a single file

https://github.com/terinjokes/gulp-uglify
https://github.com/contra/gulp-concat