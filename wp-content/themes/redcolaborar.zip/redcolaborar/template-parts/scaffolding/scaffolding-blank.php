<?php
/**
 * The template used for displaying X in the scaffolding library.
 *
 * @package Red Colaborar
 */

?>

<section class="section-scaffolding">
	<h2 class="scaffolding-heading"><?php esc_html_e( 'X', 'redcolaborar' ); ?></h2>
</section>
